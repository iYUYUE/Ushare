/** Automatically generated file. DO NOT MODIFY */
package net.iyuyue.ushare;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}